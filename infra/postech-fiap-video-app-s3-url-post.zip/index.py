import boto3
import json

s3 = boto3.client("s3")

BUCKET = "postech-fiap-bucket-videos-fase5"

def lambda_handler(event, context):
    body = event.get("body")
    if body:
        body = json.loads(body)
    else:
        body = {}

    file_name = body.get("fileName", "default.mp4")


    email = event["pathParameters"]["email"]
    key = f"videos/{email}/{file_name}"

    response = s3.generate_presigned_post(
        Bucket=BUCKET,
        Key=key,
        ExpiresIn=300
    )

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(response)
    }
